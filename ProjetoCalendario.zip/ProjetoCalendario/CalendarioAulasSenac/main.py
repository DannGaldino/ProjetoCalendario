from flask import Flask, render_template, request
import this
import login
import conexao
import menu

this.dados = ""

siteFlask = Flask(__name__) #Representando uma variável do tipo flask

@siteFlask.route('/', methods=['GET','POST'])
def menu():
    return render_template('index.html', titulo='Página Principal', resultado=this.dados)

@siteFlask.route('/loginAluno.html', methods=['GET','POST'])
def loginAluno():
        if request.method == 'POST':
            this.user = request.form['user']
            this.password = request.form['password']
            this.dados = login.loginAluno(this.email, this.password)
        return render_template('loginAluno.html', titulo='Página Principal', resultado=this.dados)



if __name__ == '__main__':
    siteFlask.run(debug=True, port=5000)

